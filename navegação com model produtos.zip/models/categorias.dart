import 'package:flutter/material.dart';

class Categoria {
  final String id;
  final String titulo;
  final Color color;
  final String imagem;

  const Categoria ( {
    required this.id,
    required this.titulo,
    this.color = Colors.orange,
    required this.imagem,
  });
}