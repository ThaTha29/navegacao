import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

import '../models/categorias.dart';

class telaprodutos extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final categoria = ModalRoute.of(context)?.settings.arguments as Categoria;
    return Scaffold(
      appBar: AppBar(
        title: Text("Tela Produtos"),
      ),
      body: Image.asset(categoria.imagem),
    );
  }
}
