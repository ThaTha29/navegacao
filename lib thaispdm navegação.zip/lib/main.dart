import 'package:backendpdmnavegacao/telas/tela_categoria.dart';
import 'package:backendpdmnavegacao/telas/tela_produtos.dart';
import 'package:backendpdmnavegacao/utils/rotas.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MeuCardapio());
}

class MeuCardapio extends StatelessWidget {
  @override //subscrever metodo para criar elemento de widget
  Widget build(BuildContext context) {
    return MaterialApp(
        title: "Cardápio",
        theme: ThemeData(
          primaryColor: Colors.blue,
        ),
        // home: TelaCategorias(),
        routes: {
          Rotas.HOME: (ctx) => TelaCategorias(),
          Rotas.PRODUTOS: (ctx) => telaprodutos()
        });
  }
}
