import 'package:flutter/material.dart';
import '../models/categorias.dart';

const mockCategories = [
  Categoria(
      id: 'c1',
      titulo: 'Italiano',
      color: Colors.purple,
      imagem: 'assets/images/comida_italiana.jpg'),
  Categoria(
      id: 'c2',
      titulo: 'Rápido & Fácil',
      color: Colors.red,
      imagem: 'assets/images/comida_rapida_facil.jpg'),
  Categoria(
      id: 'c3',
      titulo: 'Hamburgers',
      color: Colors.orange,
      imagem: 'assets/images/comida_hamburguer.jpg'),
  Categoria(
      id: 'c4',
      titulo: 'Alemã',
      color: Colors.amber,
      imagem: 'assets/images/comida_alema.jpg'),
  Categoria(
      id: 'c5',
      titulo: 'Leve & Saudável',
      color: Colors.indigo,
      imagem: 'assets/images/comida_leve_saudavel.jpg'),
  Categoria(
      id: 'c6',
      titulo: 'Exótica',
      color: Colors.green,
      imagem: 'assets/images/comida_exotica.jpg'),
  Categoria(
      id: 'c7',
      titulo: 'Café da Manhã',
      color: Colors.lightBlue,
      imagem: 'assets/images/comida_cafe_manha.jpg'),
  Categoria(
      id: 'c8',
      titulo: 'Asiática',
      color: Colors.lightGreen,
      imagem: 'assets/images/comida_asiatica.jpg'),
  Categoria(
      id: 'c9',
      titulo: 'Francesa',
      color: Colors.pink,
      imagem: 'assets/images/comida_francesa.jpg'),
  Categoria(
      id: 'c10',
      titulo: 'Verão',
      color: Colors.teal,
      imagem: 'assets/images/comida_verao.jpg'),
];
